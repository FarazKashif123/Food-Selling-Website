CREATE database RoyalRoxn;
use RoyalRoxn;
CREATE TABLE Departments (
 DepartmentName VARCHAR(255) PRIMARY KEY,
 DepartmentFunction VARCHAR(255)
);
CREATE TABLE Employees (
 EmployeeName VARCHAR(255) PRIMARY KEY,
 DepartmentName VARCHAR(255),
 FOREIGN KEY (DepartmentName) REFERENCES Departments(DepartmentName)
);
CREATE TABLE Vendors (
 VendorName VARCHAR(255) PRIMARY KEY,
 ContactInformation VARCHAR(255)
);
CREATE TABLE Realtors (
 RealtorName VARCHAR(255) PRIMARY KEY,
 VendorName VARCHAR(255),
 Position VARCHAR(255),
 Location VARCHAR(255),
 FOREIGN KEY (VendorName) REFERENCES Vendors(VendorName)
);
CREATE TABLE ColdCalling (
 DepartmentName VARCHAR(255) PRIMARY KEY,
 Functions VARCHAR(255)
);
CREATE TABLE Accounts (
 DepartmentName VARCHAR(255) PRIMARY KEY,
 Functions VARCHAR(255)
);
CREATE TABLE Marketing (
 DepartmentName VARCHAR(255) PRIMARY KEY,
 Functions VARCHAR(255)
);
CREATE TABLE DataDialerVoIP (
 DepartmentName VARCHAR(255) PRIMARY KEY,
 Functions VARCHAR(255)
);
CREATE TABLE QualityAndValidation (
 DepartmentName VARCHAR(255) PRIMARY KEY,
 Functions VARCHAR(255)
);
CREATE TABLE CallRecordings (
 AccountId INT PRIMARY KEY,
 ColdCallingDepartment VARCHAR(255),
 FOREIGN KEY (ColdCallingDepartment) REFERENCES ColdCalling(DepartmentName)
) ;
ALTER TABLE Employees
ADD CONSTRAINT FK_Employee_Department
FOREIGN KEY (DepartmentName) REFERENCES Departments(DepartmentName);
ALTER TABLE Realtors
ADD CONSTRAINT FK_Realtor_Vendor
FOREIGN KEY (VendorName) REFERENCES Vendors(VendorName);
CREATE TABLE DepartmentFunction (
 DepartmentName VARCHAR(255) ,
 PRIMARY KEY (DepartmentName),
 Functions VARCHAR(255),
 FOREIGN KEY (DepartmentName) REFERENCES Departments(DepartmentName)
);